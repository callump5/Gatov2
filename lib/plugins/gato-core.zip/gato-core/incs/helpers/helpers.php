<?php

function gcdd($item){
    echo "<pre style='background-color: lightgrey; padding: 20px'>";
    var_dump($item);
    echo "</pre>";
    die();
}
