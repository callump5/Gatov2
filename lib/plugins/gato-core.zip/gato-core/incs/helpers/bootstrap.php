<?php

// Helpers
require_once (GATO_PLUGIN_DIR . '/incs/helpers/helpers.php');

//Models
require_once (GATO_PLUGIN_DIR . '/incs/models/AdminArea.php');
require_once (GATO_PLUGIN_DIR . '/incs/models/DatabaseHandler.php');
require_once (GATO_PLUGIN_DIR . '/incs/models/ShortcodeMapper.php');